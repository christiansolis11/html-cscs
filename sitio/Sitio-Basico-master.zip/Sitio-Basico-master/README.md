# Sitio-Basico
Bienvenido a Sitio Básico
Creando Sitio Básico
Estructura de Archivos y Navbar
Información Principal
Información Secundaria y Pie de Página
Página Acerca de
Página de Contacto

